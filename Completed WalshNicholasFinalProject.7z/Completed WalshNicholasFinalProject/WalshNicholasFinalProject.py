from tkinter import *
from PIL import Image
import tkinter.font as font
from tkinter import messagebox

#----------------------------------Main Window-------------------------------------------------------------------------------------------------------------------------------
Main = Tk()
Main.title("GUI Pizza Ordering Page")
Main.iconbitmap(r'images/pizza.ico')
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



#----------------------------------Main Window Functions---------------------------------------------------------------------------------------------------------------------
#Exit Button
def exitMain():
    Main.destroy()

#Proceed to Checkout Button
def proceedChkout():
    
    #Validation to make sure the size and sauce options have been selected
    if sizeOption.get() == "":
        messagebox.showerror("Error", "Incorrect Size Chosen")
    if sauceOption.get() == "":
        messagebox.showerror("Error", "Incorrect Sauce Chosen")

    #Opens the window if validation is passed
    if sizeOption.get() != "" and sauceOption.get() != "":
        Chkout.deiconify()
        #calls appendList function
        appendList()
        
def appendList():
    
    #Creates the size, sauce, and topping labels for the customer's order on the proceed to checkout page.
    orderedSize = sizeOption.get()
    orderedSauce = sauceOption.get()
    customersOrder = orderedSize + " " + orderedSauce + " " + "Pizza"
    toppingsOrder = ""

    #Parallel array made out of lists that links the checkvalues with the topping names
    toppingList = ["Pepperoni", "Sausage", "Spicy Sausage", "Beef", "Chicken", "Onion", "Green Pepper", "Black Olive", "Green, Olive", "Provolone", "Four Cheese", "Ham", "Bacon", "Spinach", "Tomato", "Garlic Butter Crust"]
    checkList = [check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15, check16]

    #Appending the checked toppings from the checklist into a string variable to be displayed with a label.
    toppings = 0
    x = 0
    while x < len(checkList):
        topSelector = checkList[x]
        if topSelector.get() == 1:
            toppingsOrder += toppingList[x] + "," + " "
            toppings += 1
        x += 1

    #If no toppings are checked, toppingsOrder becomes "nothing"
    if toppings == 0:
        toppingsOrder = "Nothing"

    #Calculating the price of the pizza based off the size and number of toppings.
    sizePrice = 0
    if orderedSize == "Large":
        sizePrice = 15
    elif orderedSize == "Medium":
        sizePrice = 10
    elif orderedSize == "Small":
        sizePrice = 5
    calculatePrice = sizePrice + (toppings * .5)
    pizzaCost = "Cost: $" + str(calculatePrice)

    #Displays size, sauce, toppings, and cost labels onto the checkout page
    global sizeSauceLabel
    sizeSauceLabel = Label(Chkout, text=customersOrder)
    sizeSauceLabel.grid(row=2, column=0, columnspan=3)
    Label(Chkout, text="Topped With:").grid(row=3, column=0, columnspan=3)

    global toppingsLabel
    toppingsLabel = Label(Chkout, text=toppingsOrder)
    toppingsLabel.grid(row=4, column=0, columnspan=3)
    
    global totalCost
    totalCost = Label(Chkout, text=pizzaCost, font=MedSz)
    totalCost.grid(row=5, column=0, columnspan=3)
   
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



#----------------------------------Main Window Headers-----------------------------------------------------------------------------------------------------------------------

#Declaring Font Sizes
LgSz = font.Font(size=30, weight='bold')
MedSz = font.Font(size=15)
SmSz = font.Font(size=10)

#Title and Header Labels
MainTitle = Label(Main, text="Welcome to GUI Pizza Delivery", font= LgSz).grid(row=0, column=0, columnspan=3)
orderText = Label(Main, text="Enter Your Order Below", font=MedSz).grid(row=1, column=0, columnspan=3)
Label(Main, text="Choose the size of your pizza:", font= SmSz).grid(row=2, column=0)
Label(Main, text="Choose your Sauce:", font= SmSz).grid(row=2, column=2, sticky=W)
Label(Main, text="Choose your toppings:", font= SmSz).grid(row=4, column=0, sticky=W)
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



#----------------------------------Main Window Elements----------------------------------------------------------------------------------------------------------------------

#Pizza Size OptionMenu
pizzaSizes = ["Large", "Medium", "Small"]
sizeOption = StringVar()
sizeMenu = OptionMenu(Main, sizeOption, *pizzaSizes).grid(row=3, column=0)

#Pizza Sauce OptionMenu
sauceOption = StringVar()
pizzaSauces = ["Pizza Sauce", "Barbecue", "Ranch", "Garlic Butter"]
pizzaSauce = OptionMenu(Main, sauceOption, *pizzaSauces).grid(row=3, column=2, sticky=W)

#Toppings Check List
check1 = IntVar()
pizzaPep = Checkbutton(Main, text="Pepperoni", onvalue= 1, variable=check1)
pizzaPep.grid(row=5, column=0, sticky=W)

check2 = IntVar()
pizzaSg = Checkbutton(Main, text="Sausage", onvalue= 1, variable=check2)
pizzaSg.grid(row=6, column=0, sticky=W)

check3 = IntVar()
pizzaSsg = Checkbutton(Main, text="Spicy Sausage", variable=check3)
pizzaSsg.grid(row=7, column=0, sticky=W)

check4 = IntVar()
pizzaBf = Checkbutton(Main, text="Beef", onvalue= 1, variable=check4)
pizzaBf.grid(row=8, column=0, sticky=W)

check5 = IntVar()
pizzaCkn = Checkbutton(Main, text="Chicken", onvalue= 1, variable=check5)
pizzaCkn.grid(row=9, column=0, sticky=W)

check6 = IntVar()
pizzaOni = Checkbutton(Main, text="Onion", onvalue= 1, variable=check6)
pizzaOni.grid(row=10, column=0, sticky=W)

check7 = IntVar()
pizzaGp = Checkbutton(Main, text="Green Pepper", onvalue= 1, variable=check7)
pizzaGp.grid(row=11, column=0, sticky=W)

check8 = IntVar()
pizzaBo = Checkbutton(Main, text="Black Olive", onvalue= 1, variable=check8)
pizzaBo.grid(row=12, column=0, sticky=W)

check9 = IntVar()
pizzaGo = Checkbutton(Main, text="Green Olive", onvalue= 1, variable=check9)
pizzaGo.grid(row=5, column=2, sticky=W)

check10 = IntVar()
pizzaProv = Checkbutton(Main, text="Provolone Cheese", onvalue= 1, variable=check10)
pizzaProv.grid(row=6, column=2, sticky=W)

check11 = IntVar()
pizzaChz = Checkbutton(Main, text="Four Cheese", onvalue= 1, variable=check11)
pizzaChz.grid(row=7, column=2, sticky=W)

check12 = IntVar()
pizzaHam = Checkbutton(Main, text="Ham", onvalue= 1, variable=check12)
pizzaHam.grid(row=8, column=2, sticky=W)

check13 = IntVar()
pizzaBac = Checkbutton(Main, text="Bacon", onvalue= 1, variable=check13)
pizzaBac.grid(row=9, column=2, sticky=W)

check14 = IntVar()
pizzaSpin = Checkbutton(Main, text="Spinach", onvalue= 1, variable=check14)
pizzaSpin.grid(row=10, column=2, sticky=W)

check15 = IntVar()
pizzaTom = Checkbutton(Main, text="Tomato", onvalue= 1, variable=check15)
pizzaTom.grid(row=11, column=2, sticky=W)

check16 = IntVar()
pizzaGbC = Checkbutton(Main, text="Garlic Butter on Crust", onvalue= 1, variable=check16)
pizzaGbC.grid(row=12, column=2, sticky=W)

#Exit Button
Label(Main, text="").grid(row=13, column=0)
exitButton = Button(Main, text="Exit Menu", command=exitMain).grid(row=14, column=0, sticky=SW)

#Proceed to Checkout Button
Label(Main, text="").grid(row=13, column=2)
mainButton = Button(Main, text="Proceed to Checkout", command=proceedChkout).grid(row=14, column=2, sticky=E)
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""



-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



"""
#-------------------------------------Checkout Window------------------------------------------------------------------------------------------------------------------------
Chkout = Toplevel(Main)
Chkout.title("GUI Pizza Checkout Page")
Chkout.iconbitmap(r'images/pizza.ico')
Chkout.withdraw()
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



#---------------------------------Checkout Window Functions------------------------------------------------------------------------------------------------------------------

#Back Button
def backButton():
    
    #Resets labels for customers order, allowing them to change their order if needed.
    sizeSauceLabel.destroy()
    toppingsLabel.destroy()
    totalCost.destroy()
    
    #Hides window
    Chkout.withdraw()

#Validation for user's information to order the pizza.
def validateOrder():
    #Validation to make sure no numbers are entered into the first name entry box.
    for character in fnameEntry.get():
        if character.isdigit():
            messagebox.showerror("Error", "Numbers are not allowed in first name entry.")
            break

    #Validation to make sure no numbers are entered into the last name entry box.        
    for character in lnameEntry.get():
        if character.isdigit():
            messagebox.showerror("Error", "Numbers are not allowed in last name entry.")
            break
            
    #Validates first name is entered and not a number
    if fnameEntry.get() == "":
        messagebox.showerror("Error", "Please enter your first name.")
    elif fnameEntry.get().isdigit():
        messagebox.showerror("Error", "Numbers are not allowed in first name entry.")

    #Validates last name is entered and not a number
    elif lnameEntry.get() == "":
        messagebox.showerror("Error", "Please enter your last name.")
    elif lnameEntry.get().isdigit():
        messagebox.showerror("Error", "Numbers are not allowed in last name entry.")

    #Validates address is entered
    elif addressEntry.get() == "":
        messagebox.showerror("Error", "Please enter your address for delivery.")

    #Validates card info is entered and no more or less than 16 digits long
    elif cardInfoEntry.get() == "":
        messagebox.showerror("Error", "Please enter your card number.")
    elif len(cardInfoEntry.get()) != 16:
        messagebox.showerror("Error", "Please enter 16 numbers for your card.")

    #Validates expiration date is entered and no more or less than 4 digits long
    elif expDateEntry.get() == "":
        messagebox.showerror("Error", "Please enter your card expiration date.")
    elif len(expDateEntry.get()) != 4:
        messagebox.showerror("Error", "Please enter 4 numbers for exp date.")

    #Validates CVV is entered and no more or less than 3 digits is entered
    elif cvvEntry.get() == "":
        messagebox.showerror("Error", "Please enter your cvv number.")
    elif len(cvvEntry.get()) != 3:
        messagebox.showerror("Error", "Please enter 3 numbers for cvv.")

    #Validates all card info, making sure the entries are numbers only.    
    elif cardInfoEntry.get().isdigit() and expDateEntry.get().isdigit() and cvvEntry.get().isdigit():
        orderPizza()
    else:
        messagebox.showerror("Error", "Please enter numbers only for your card information.")

#Order Button
def orderPizza():
    #Appends entry values into their labels on the order page
    fullName = fnameEntry.get() + " " + lnameEntry.get()
    nameInfo['text'] = fullName

    orderAddress = addressEntry.get()
    addressInfo['text'] = orderAddress

    orderCard = cardInfoEntry.get()
    cardInfo['text'] = orderCard
    
    #Shows order page window
    orderPage.deiconify()
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



#-------------------------------------Checkout Elements----------------------------------------------------------------------------------------------------------------------

#Title and Header Labels
chkoutTitle = Label(Chkout, text="GUI Pizza Checkout", font=LgSz).grid(row=0, column=0, columnspan=3)
chkoutOrder = Label(Chkout, text="Your Order:", font=MedSz).grid(row=1, column=0, columnspan=3)
checkoutHeader = Label(Chkout, text="Checkout Here:", font=MedSz).grid(row=6, column=0)

#Entry Labels
fnameText = Label(Chkout, text="First Name:").grid(row=7, column=0)
fnameEntry = Entry(Chkout, width=15)
fnameEntry.grid(row=8, column=0)

Label(Chkout, text="").grid(row=7, column=1)
lnameText = Label(Chkout, text="Last Name:").grid(row=7, column=2)
lnameEntry = Entry(Chkout, width=15)
lnameEntry.grid(row=8, column=2)

addressText = Label(Chkout, text="Address For Delivery:").grid(row=9, column=0, sticky=W)
addressEntry = Entry(Chkout, width=35)
addressEntry.grid(row=10, column= 0, columnspan=2, sticky=W)

cardInfoText = Label(Chkout, text="Credit Card Information:").grid(row=11, column=0, sticky=W)
cardInfoEntry = Entry(Chkout, width=25)
cardInfoEntry.grid(row=12, column=0, sticky=W)

expDateText = Label(Chkout, text="Exp").grid(row=11, column=1)
expDateEntry = Entry(Chkout, width=5)
expDateEntry.grid(row=12, column=1)

cvvText = Label(Chkout, text="CVV").grid(row=11, column=2)
cvvEntry = Entry(Chkout, width=3)
cvvEntry.grid(row=12, column=2)

paymentTypes = PhotoImage(file='images/Payment.png')
paymentLabel = Label(Chkout, image= paymentTypes).grid(row=13, column=0, sticky=W)

#Back Button
Label(Chkout, text="").grid(row=14, column=0)
backButton = Button(Chkout, text="Go Back", command=backButton).grid(row=15, column=0, sticky=SW)

#Order Button
Label(Chkout, text="").grid(row=14, column=2)
orderButton = Button(Chkout, text="Order Pizza", command=validateOrder).grid(row=15, column=2, sticky=SE)
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""



-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------




"""
#-------------------------------------Order Successful Window----------------------------------------------------------------------------------------------------------------
orderPage = Toplevel(Main)
orderPage.title("GUI Pizza Delivery")
orderPage.iconbitmap(r'images/pizza.ico')
orderPage.withdraw()
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



#------------------------------------Order Page Functions--------------------------------------------------------------------------------------------------------------------

#Exit Button function that closes all windows
def orderExit():
    orderPage.destroy()
    Chkout.destroy()
    Main.destroy()
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    
#-------------------------------------Order Page Headers---------------------------------------------------------------------------------------------------------------------

#Headers and Image
orderTitle = Label(orderPage, text= "Thank You For Ordering At", font=LgSz).grid(row=0, column=0, columnspan=3)
orderTitle_ = Label(orderPage, text="GUI Pizza", font=LgSz).grid(row=1, column=0, columnspan=3)

successImg = PhotoImage(file='images/OrderSuccess.png')
sucessImgLabel = Label(orderPage, image= successImg).grid(row=2, column=0, columnspan=3)
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



#-------------------------------------Order Page Elements--------------------------------------------------------------------------------------------------------------------

#Text Labels
orderSuccessful = Label(orderPage, text="Order Successful", font=MedSz).grid(row=3, column=0, columnspan=3)
Label(orderPage, text="").grid(row=4, column=0)

nameHeader = Label(orderPage, text="Name: ").grid(row=5, column=0, sticky=W)
nameInfo = Label(orderPage, text="")
nameInfo.grid(row=5, column=1, sticky=W)

addressHeader = Label(orderPage, text="Address: ").grid(row=6, column=0, sticky=W)
addressInfo = Label(orderPage, text="")
addressInfo.grid(row=6, column=1, sticky=W)

cardInfoHeader = Label(orderPage, text="Credit Card Information: ").grid(row=7, column=0, sticky=W)
cardInfo = Label(orderPage, text="")
cardInfo.grid(row=7, column=1, sticky=W)

#Exit Button
Label(orderPage, text="").grid(row=8, column=0)
orderButton = Button(orderPage, text="Exit", width=10, command=orderExit).grid(row=9, column=0, columnspan=3)
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Main.mainloop()
